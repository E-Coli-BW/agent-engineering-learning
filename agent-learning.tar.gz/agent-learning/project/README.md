# 🏗️ 工程化 RAG 系统 (`project/`)

> 之前所有模块都是"教学脚本"——跑一下看效果。
> 这个目录是**真实工程级别**的实现，弥补和生产系统的差距。

## 解决的差距

| 差距 | 之前 | 现在 |
|------|------|------|
| 数据处理 | 硬编码 fake data | 真实 ETL Pipeline (多格式文件 → 清洗 → 分块 → 入库) |
| 可服务性 | 独立 `.py` 脚本 | FastAPI REST API (可供前端/其他系统调用) |
| 错误处理 | 几乎为零 | 超时重试、降级策略、结构化日志 |
| 配置管理 | 硬编码到处都是 | 统一 Config + 环境变量覆盖 |
| 增量更新 | 每次全量重建 | content_hash 去重 + 增量入库 |
| 流式输出 | 无 | SSE 流式响应 |
| 可观测性 | 无 | /health + /metrics 端点 |

## 文件说明

```
project/
├── config.py          # 统一配置管理 (环境变量覆盖)
├── etl_pipeline.py    # ETL: Extract → Transform → Load
├── api_server.py      # FastAPI RAG API Server
└── README.md          # 本文件
```

## 使用方式

### Step 1: 安装额外依赖

```bash
pip install fastapi uvicorn
```

### Step 2: 运行 ETL (构建索引)

```bash
python project/etl_pipeline.py
```

会扫描项目中所有 `.py` / `.md` 文件 → 清洗 → 分块 → 向量化 → 存入 ChromaDB。

### Step 3: 启动 API Server

```bash
python project/api_server.py
```

访问 http://localhost:8000/docs 查看自动生成的 API 文档。

### Step 4: 测试

```bash
# 健康检查
curl http://localhost:8000/health

# 查询
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"question": "LoRA 微调的原理是什么？"}'

# 流式查询
curl -N -X POST http://localhost:8000/query/stream \
  -H "Content-Type: application/json" \
  -d '{"question": "Transformer 的注意力机制如何工作？"}'

# 指标
curl http://localhost:8000/metrics
```

### 环境变量配置

```bash
# 换模型
export CHAT_MODEL=qwen2.5:3b
export EMBED_MODEL=mxbai-embed-large

# 换端口
export API_PORT=3000

# 调参数
export TOP_K=3
export CHUNK_SIZE=800
```
